/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animacionciudad;

/**
 * Clase principal que crea una instancia de la clases Ventana
 * @author Camiku
 */
public class AnimacionCiudad {

    /**
     * Crea una nueva instancia de la clase Ventana
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ventana ventana = new Ventana();
    }
    
}
